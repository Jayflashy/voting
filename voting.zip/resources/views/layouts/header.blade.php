<header class="header">
    <nav class="navbar navbar-expand-md fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="{{route('index')}}">
                <img src="{{my_asset(get_setting('logo') )}}" alt="{{get_setting('title')}}" class="logo">
            </a>
            <a href="{{route('index')}}" class="btn btn-primary"> @lang('Show All Categories')</a>
        </div>
    </nav>
</header>

