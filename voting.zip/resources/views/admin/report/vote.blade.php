@extends('admin.layouts.master')
@section('title') @lang('Voting History') @endsection

@section('content')
<div class="card">
    <h4 class="card-header fw-bold">@lang('Voting History')</h4>
    <div class="card-body">

    </div>
</div>

@endsection
